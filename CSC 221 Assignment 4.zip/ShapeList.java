import java.util.TreeSet;

public class ShapeList extends TreeSet<Shape> {

    /**
     * A function that adds the object, otherwise checks if it is stored
     * @param other
     * @return true or false
     */
    public boolean add(Shape other) {
        if (contains(other)) {
            return false;
        }
        else {
            super.add(other);
            return true;
        }
    }

    /**
     * A function that returns all of 2D shapes from the Shapelist
     * @return all of the 2D shapes
     */
    public ShapeList get2DShapes() {
        ShapeList Shapes2D = new ShapeList();
        for (Shape other : this) {
            if (other instanceof Quadrilateral) {
                Shapes2D.add(other);
            }
        }
        return Shapes2D;
    }

    /**
     * A function that returns all of 3D shapes from the Shapelist
     * @return all of the 3D shapes
     */
    public ShapeList get3DShapes() {
        ShapeList Shapes3D = new ShapeList();
        for (Shape other : this) {
            if (other instanceof Quadrilateral3D) {
                Shapes3D.add(other);
            }
        }
        return Shapes3D;
    }

    /**
     * Gets the size
     * @return the size
     */
    int getSize() {
        return super.size();
    }

    /**
     * Prints out the assignment
     */
    public void printFormatted() {
            System.out.printf("+--------+-------------+---------+-------------------------+------------+----------------------+");
            System.out.printf("%n%s %-6s %s %-11s %s %-7s %s %-23s %s %-10s %s %-20s %s","|", "ID", "|" , "Name", "|", "Color", "|", "Dimensions", "|", "Area", "|", "Description", "|");
            System.out.printf("%n%s", "+--------+-------------+---------+-------------------------+------------+----------------------+");
            for (Shape i : this) {
                String str = String.format("%,.2f", i.area());
                String a = i.toString();
                String b[] = a.split(" ");
                if (i instanceof Quadrilateral) {
                    System.out.printf("%n%s %-6s %s %-11s %s %-7s %s %-23s %s %-10s %s %-20s %s", "|", i.ID, "|" , i.NAME, "|", b[5], "|", i.getDimensions(), "|", str, "|", i.DESCRIPTION, "|");

                } else if (i instanceof Quadrilateral3D) {
                    System.out.printf("%n%s %-6s %s %-11s %s %-7s %s %-23s %s %-10s %s %-20s %s", "|", i.ID, "|" , i.NAME, "|", b[5], "|", i.getDimensions(), "|", str, "|", i.DESCRIPTION, "|");
                }
                System.out.printf("%n%s", "+--------+-------------+---------+-------------------------+------------+----------------------+");
            }
        }
    }

