import java.awt.*;

public class Quadrilateral extends Shape2D {

    /**
     * Constructor of the Quadtilateral class
     * @param ID
     * @param name
     * @param description
     * @param Color
     * @param height
     * @param width
     */
    public Quadrilateral(int ID, String name, String description, Color Color, double height, double width) {
        super(ID, name, description, Color, height, width);
    }

    /**
     * the area of the quadrilateral
     * @return the area
     */
    @Override
    public double area() {
        double area = WIDTH * HEIGHT;
        return area;
    }

    /**
     * the perimeter of the quadrilateral
     * @return the perimeter
     */
    @Override
    public double perimeter() {
        double perimeter = 2 * (HEIGHT + WIDTH);
        return perimeter;
    }

}