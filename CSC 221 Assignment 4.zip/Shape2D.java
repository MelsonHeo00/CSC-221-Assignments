import java.awt.*;

public abstract class Shape2D extends Shape {

    /**
     * Declaration of the HEIGHT and WIDTH
     */
    public final double HEIGHT;
    public final double WIDTH;

    /**
     * Shape2D Constructor
     * @param ID
     * @param name
     * @param description
     * @param Color
     * @param height
     * @param width
     */
    public Shape2D(int ID, String name, String description, Color Color, double height, double width) {
        super(ID, name, description, Color);
        this.WIDTH = width;
        this.HEIGHT = height;
    }

    /**
     * @return the string method for Shape 2D
     */
    @Override
    public String toString() {
        return String.format("%s %.2f %.2f", super.toString(), HEIGHT, WIDTH);
    }

    /**
     * A function that will return the values of the width and height
     * @return WIDTH and HEIGHT with 2 precision
     */
    public String getDimensions() {
        return String.format("%.2f %s %.2f", HEIGHT, "X", WIDTH);
    }

    /**
     * A function that will return the results based on the compareTo
     * @param other
     * @return result, otherwise 0
     */
    @Override
    public int compareTo(Shape other) {
        int result = super.compareTo(other);
        if (result == 0 && other instanceof Shape2D) {
            Shape2D shape = (Shape2D)other;
            result = Double.compare(this.HEIGHT, shape.HEIGHT);
            if (result == 0){
                result = Double.compare(this.WIDTH, shape.WIDTH);
            }
        }
        return result;
    }

}