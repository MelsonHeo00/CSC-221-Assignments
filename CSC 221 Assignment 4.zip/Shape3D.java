import java.awt.*;

public abstract class Shape3D extends Shape2D {

    /**
     * Declaration of the LENGTH Variable
     */
    public final double LENGTH;

    /**
     * Constructor for Shape3D
     * @param ID
     * @param name
     * @param description
     * @param Color
     * @param height
     * @param width
     * @param length
     */
    public Shape3D(int ID, String name, String description, Color Color, double height, double width, double length) {
        super(ID, name, description, Color, height, width);
        this.LENGTH = length;
    }

    /**
     * @return the String values
     */
    @Override
    public String toString() {
        return String.format("%s %.2f %.2f %.2f", super.toString(), HEIGHT, WIDTH, LENGTH);
    }

    /**
     * A function that will return the values of the width, height, and length
     * @return WIDTH, HEIGHT, and LENGTH with 2 precision
     */
    public String getDimensions() {
        return String.format("%.2f %s %.2f %s %.2f", HEIGHT, "X", WIDTH, "X", LENGTH);
    }

    @Override
    public int compareTo(Shape other) {
        int result = super.compareTo(other);
        if (result == 0 && other instanceof Shape3D) {
            Shape3D shape = (Shape3D) other;
            result = Double.compare(shape.LENGTH, this.LENGTH);
        }
        return result;
    }
}
