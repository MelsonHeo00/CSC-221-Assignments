import java.awt.*;

public abstract class Shape implements Comparable<Shape> {

    /**
     * Declaration of the variables
     */
    public final int ID;
    public final String NAME;
    public final String DESCRIPTION;
    public final Color COLOR;

    /**
     * Constructor
     * @param ID
     * @param name
     * @param description
     * @param Color
     */
    public Shape(int ID, String name, String description, Color Color) {
        this.ID = ID;
        this.NAME = name;
        this.DESCRIPTION = description;
        this.COLOR = Color;

    }

    /**
     * three abstract methods
     */
    public abstract double area();
    public abstract double perimeter();
    public abstract String getDimensions();

    /**
     * @return the name of the Color as a String
     */
    public String getColorName(Color other) {
        if (Color.BLACK.equals(other)) {
            return "Black";
        } else if (Color.WHITE.equals(other)) {
            return "White";
        } else if (Color.BLUE.equals(other)) {
            return "Blue";
        } else if (Color.CYAN.equals(other)) {
            return "Cyan";
        } else if (Color.YELLOW.equals(other)) {
            return "Yellow";
        } else if (Color.GREEN.equals(other)) {
            return "Green";
        } else if (Color.RED.equals(other)) {
            return "Red";
        } return null;
    }

    /**
     * @return the string of the field
     */
    public String toString()  {
        return String.format("%d %s %s %s", ID, NAME, DESCRIPTION, getColorName(this.COLOR));
    }

    /**
     * Comparing the two objects of type Shape
     * @param other
     * @return values
     */
    public int compareTo(Shape other) {
        int result = this.NAME.compareTo(other.NAME);
        if (result == 0) {
            result = this.getColorName(this.COLOR).compareTo(other.getColorName(other.COLOR));
        }
        return result;
    }

}
