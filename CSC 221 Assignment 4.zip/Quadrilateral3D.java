import java.awt.*;

public class Quadrilateral3D extends Shape3D {

    /**
     * the constructor of the quadrilateral3D
     * @param ID
     * @param name
     * @param description
     * @param Color
     * @param height
     * @param width
     * @param length
     */
    public Quadrilateral3D(int ID, String name, String description, Color Color, double height, double width, double length) {
        super(ID ,name, description, Color, height, width, length);
    }

    /**
     * the area of the quadrilateral 3D
     * @return the area
     */
    @Override
    public double area() {
        double area = 2 * (WIDTH * HEIGHT + WIDTH * LENGTH + HEIGHT * LENGTH);
        return area;
    }

    /**
     * the perimeter of the quadrilateral 3D
     * @return the perimeter
     */
    @Override
    public double perimeter() {
        double perimeter = 4 * (WIDTH + LENGTH + HEIGHT);
        return perimeter;
    }
    
}