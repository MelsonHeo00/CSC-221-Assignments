package edu.cuny.ccny.assignment_5;

public class A5Circle {

    double X;
    double Y;
    double Radius;
    String Color;

    public A5Circle() {
        this(0,0,0,"");
    }


    public A5Circle(double X, double Y, double Radius, String Color) {
        this.X = X;
        this.Y = Y;
        this.Radius = Radius;
        this.Color = Color;
    }


    public double getX() {
        return X;
    }

    public void setX(double X) {
        this.X = X;
    }

    public double getY() {
        return Y;
    }

    public void setY(double Y) {
        this.Y = Y;
    }

    public double getRadius() {
        return Radius;
    }

    public void setRadius(double Radius) {
        this.Radius = Radius;
    }

}
