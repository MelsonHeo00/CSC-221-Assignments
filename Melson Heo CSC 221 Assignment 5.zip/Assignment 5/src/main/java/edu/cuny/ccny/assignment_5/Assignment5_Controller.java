package edu.cuny.ccny.assignment_5;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Assignment5_Controller {

    private enum DrawShape {

        CIRCLE("Circle"), RECTANGLE("Rectangle");

        private final String name;

        DrawShape(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    private enum PenSize {

        SMALL(2,4,6),
        MEDIUM(6,8,10),
        LARGE(10,12,14),
        XLARGE(14,16,18);

        private final int radius;
        private final int height;
        private final int width;

        PenSize(int radius, int width, int height) {
            this.radius = radius;
            this.height = height;
            this.width = width;
        }
    }

    private enum DrawColor {

        BLACK(Color.BLACK),
        RED(Color.RED),
        GREEN(Color.GREEN),
        BLUE(Color.BLUE);

        private final Color color;

        DrawColor(Color color) {
            this.color = color;
        }
    }


    @FXML
    private Button btnExit;

    @FXML
    private Button btnReset;

    @FXML
    private Button btnSaveXML;

    @FXML
    private Button btnUndo;

    @FXML
    private Pane panelDraw;

    @FXML
    private RadioButton rBtnBlack;

    @FXML
    private RadioButton rBtnBlue;

    @FXML
    private RadioButton rBtnGreen;

    @FXML
    private RadioButton rBtnLarge;

    @FXML
    private RadioButton rBtnMedium;

    @FXML
    private RadioButton rBtnRed;

    @FXML
    private RadioButton rBtnSmall;

    @FXML
    private RadioButton rBtnXLarge;

    @FXML
    private ComboBox<DrawShape> selectShape;

    @FXML
    private ToggleGroup tgColor;

    @FXML
    private ToggleGroup tgPenSize;

    private DrawColor drawColor = DrawColor.BLACK;
    private PenSize penSize = PenSize.MEDIUM;
    private DrawShape drawShape = DrawShape.CIRCLE;

    @FXML
    void colorChangeEventHandler() {
        if (rBtnBlack.isSelected())
            drawColor = DrawColor.BLACK;
        else if (rBtnGreen.isSelected())
            drawColor = DrawColor.GREEN;
        else if (rBtnRed.isSelected())
            drawColor = DrawColor.RED;
        else
            drawColor = DrawColor.BLUE;
    }

    @FXML
    void drawingAreaMouseDragged(MouseEvent event) {

        if(drawShape == DrawShape.CIRCLE) {
            if (panelDraw.getLayoutBounds().contains(event.getX() - penSize.radius, event.getY() - penSize.radius) &&
                    panelDraw.getLayoutBounds().contains(event.getX() + penSize.radius, event.getY() + penSize.radius)) {
                    panelDraw.getChildren().add(new Circle(event.getX(), event.getY(), penSize.radius, drawColor.color));
                }
            }

        // Implements the rectangle drawing and prevents any overflow
        else {
            if (panelDraw.getLayoutBounds().contains(event.getX() - penSize.width, event.getY() - penSize.height) &&
                    panelDraw.getLayoutBounds().contains(event.getX() + penSize.width, event.getY() + penSize.height)) {
                Rectangle rectangle = new Rectangle(event.getX(), event.getY(), penSize.width, penSize.height);
                panelDraw.getChildren().add(rectangle);
                rectangle.setFill(drawColor.color);
            }
        }
        }

    @FXML
    void penSizeChangeEventHandler() {

        if (rBtnSmall.isSelected())
            penSize = PenSize.SMALL;
        else if (rBtnMedium.isSelected())
            penSize = PenSize.MEDIUM;
        else if (rBtnXLarge.isSelected())
            penSize = PenSize.XLARGE;
        else
            penSize = PenSize.LARGE;
    }

    @FXML
    void drawShapeEventHandler() {
        if (selectShape.getValue() == DrawShape.CIRCLE) {
            drawShape = DrawShape.CIRCLE;
        }

        // Outputs a rectangle shape
        else {
            drawShape = DrawShape.RECTANGLE;
        }
    }

    @FXML
    void resetButtonEventHandler() {
        panelDraw.getChildren().clear();
        rBtnBlack.setSelected(true);
        rBtnSmall.setSelected(true);
        colorChangeEventHandler();
        penSizeChangeEventHandler();
        selectShape.setValue(DrawShape.CIRCLE);
    }

    @FXML
    void undoButtonEventHandler() {

        if (!panelDraw.getChildren().isEmpty())
            panelDraw.getChildren().remove(panelDraw.getChildren().size() - 1);
    }

    @FXML
    void exitButtonEventHandler() {
        Platform.exit();
    }

    @FXML
    void saveButtonEventHandler() {

        // FileChooser
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select an XML File");
        fileChooser.setInitialDirectory(new File("."));

        // Extension
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("XML", "*.xml"));
        File file = fileChooser.showSaveDialog(new Stage());

        // the pattern of the file name
        String FilePattern = "^[A-Z][a-zA-Z0-9]{4,}.xml$";

        // getting the file name
        String FileName = file.getName();

        // Checks if the file name meets the patten requirements
        if ((FileName.matches(FilePattern))) {
            try (FileOutputStream script = new FileOutputStream(FileName)) {
                try (XMLEncoder encode = new XMLEncoder(script)) {
                    for (Node children : panelDraw.getChildren()) {
                        if (children instanceof Rectangle) {
                            Rectangle rec = (Rectangle) children;
                            A5Rectangle rectangle = new A5Rectangle(rec.getX(), rec.getY(), rec.getWidth(), rec.getHeight(), rec.getFill().toString());
                            encode.writeObject(rectangle);
                        }
                    }
                }
            }
            catch (IOException error) {
                error.printStackTrace();
            }
        }

        else {
            // the error message
            System.err.println("Error");
        }

    }

    @FXML
    void initialize() {

        assert btnExit != null : "fx:id=\"btnExit\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert btnReset != null : "fx:id=\"btnReset\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert btnUndo != null : "fx:id=\"btnUndo\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert panelDraw != null : "fx:id=\"panelDraw\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnBlack != null : "fx:id=\"rBtnBlack\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnBlue != null : "fx:id=\"rBtnBlue\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnGreen != null : "fx:id=\"rBtnGreen\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnLarge != null : "fx:id=\"rBtnLarge\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnMedium != null : "fx:id=\"rBtnMedium\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnRed != null : "fx:id=\"rBtnRed\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnSmall != null : "fx:id=\"rBtnSmall\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert rBtnXLarge != null : "fx:id=\"rBtnXLarge\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert selectShape != null : "fx:id=\"selectShape\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert tgColor != null : "fx:id=\"tgColor\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert tgPenSize != null : "fx:id=\"tgPenSize\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";
        assert btnSaveXML != null : "fx:id=\"btnSaveXML\" was not injected: check your FXML file 'PainterAssignment5.fxml'.";


        // initial state setup
        selectShape.getItems().addAll(DrawShape.values());
        selectShape.setValue(selectShape.getItems().get(0));
    }
}