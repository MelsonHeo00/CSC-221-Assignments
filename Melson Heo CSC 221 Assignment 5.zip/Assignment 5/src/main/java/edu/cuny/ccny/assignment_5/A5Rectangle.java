package edu.cuny.ccny.assignment_5;

public class A5Rectangle {

    double X;
    double Y;
    double Width;
    double Height;
    String Color;

    public A5Rectangle() {
        this(0,0,0,0,"");
    }

    public A5Rectangle(double X, double Y, double Width, double Height, String Color) {
        this.X = X;
        this.Y = Y;
        this.Width = Width;
        this.Height = Height;
        this.Color = Color;
    }

    public double getX() {
        return X;
    }

    public void setX(double x) {
        this.X = x;
    }

    public double getY() {
        return Y;
    }

    public void setY(double Y) {
        this.Y = Y;
    }

    public double getWidth() {
        return Width;
    }

    public void setWidth(double Width) {
        this.Width = Width;
    }

    public double getHeight() {
        return Height;
    }

    public void setHeight(double Height) {
        this.Height = Height;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

}