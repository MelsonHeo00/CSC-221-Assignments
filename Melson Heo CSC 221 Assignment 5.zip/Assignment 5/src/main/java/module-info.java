module edu.cuny.ccny.assignment_5 {

    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.desktop;

    opens edu.cuny.ccny.assignment_5 to javafx.fxml;
    exports edu.cuny.ccny.assignment_5;
}