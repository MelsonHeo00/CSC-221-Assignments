import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class LogUtility {

    /**
     * declaration of the listLogEntry
     */
    private final ArrayList<LogEntry> listLogEntry;

    /**
     * default constructor
     */
    public LogUtility() {
        listLogEntry = new ArrayList<LogEntry>();
    }

    /**
     * the class that reads all the lines from Network.log
     * @param fileName
     * @throws FileNotFoundException
     */
    public void parseFile(String fileName) throws FileNotFoundException{
        File file = new File(fileName);
        try(Scanner fileInput = new Scanner(new FileInputStream(file))) {
            while(fileInput.hasNext()) {
                String line = fileInput.nextLine();
                String[] arr = line.split(",");
                if(arr.length == 7) {
                    try {
                        listLogEntry.add(new LogEntry(arr[0], arr[1],arr[2], arr[3], arr[4], arr[5], arr[6]));
                    } catch(Exception ie) {
                        System.err.printf("Skipping Line: %s%n", line);
                    }
                }
                else {
                    System.err.printf("Skipping Line: %s%n", line);
                }
            }
            fileInput.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * @return the String message to show valid entries
     */
    public String toString() {
        return "LogUtility: there are " + listLogEntry.size() + " valid records";
    }

    /**
     * records of entry dates
     * @param fromDate
     * @param toDate
     * @return a list of records between the date strings parameters
     * @throws ParseException
     */
    public ArrayList<LogEntry> getBetween(String fromDate, String toDate) throws ParseException{
        SimpleDateFormat form = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date startDate = form.parse(fromDate);
        Date endDate = form.parse(toDate);
        ArrayList<LogEntry> list = new ArrayList<>();

        for(LogEntry log : listLogEntry) {
            Date dateTime = form.parse(log.getDateTime());
            if((dateTime.compareTo(startDate) >= 0) && (dateTime.compareTo(endDate) <=0)) {list.add(log);}
        }

        return list;
    }


    /**
     * an enumerator to distinguish each fields
     * @param input
     * @param field
     * @return log or null
     */
    public LogEntry findFirst(String input, String field) {
        for(LogEntry log : listLogEntry) {
            String output;

            switch(field) {
                case "Sequence":
                    output = log.getSequence();
                    break;
                case "Time":
                    output = log.getDateTime();
                    break;
                case "SourceIP":
                    output = log.getSourceIP();
                    break;
                case "DestinationIP":
                    output = log.getDestinationIP();
                    break;
                case "Protocol":
                    output = log.getProtocol();
                    break;
                case "PacketSize":
                    output = log.getPacketSize();
                    break;
                case "Comment":
                    output = log.getComment();
                    break;
                default:
                    output = null;
            }
            if(output.equals(input)) {
                return log;
            }
        }
        return null;
    }

    /**
     * 7 common methods
     * @param str
     * @return all the 7 common methods
     */

    public LogEntry findFirstId(String str) {
        return findFirst(str, "Sequence");
    }

    public LogEntry findFirstTimestamp(String str) {
        return findFirst(str, "Time");
    }

    public LogEntry findFirstSourceIP(String str) {
        return findFirst(str, "SourceIP");
    }

    public LogEntry findFirstDestinationIP(String str) {
        return findFirst(str, "DestinationIP");
    }

    public LogEntry findFirstProtocol(String str) {
        return findFirst(str, "Protocol");
    }

    public LogEntry findFirstLength(String str) {
        return findFirst(str, "PacketSize");
    }

    public LogEntry findFirstDescription(String str) {
        return findFirst(str, "Comment");
    }


}