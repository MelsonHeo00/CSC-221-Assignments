import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogEntry {

    /**
     * the 7 ReadOnly values declared
     */
    private final String comment;
    private final String protocol;
    private final String destinationIP;
    private final String sourceIP;
    private final String dateTime;
    private final String packetSize;
    private final String sequence;

    /**
     * default constructor for LogEntry
     * @param sequence
     * @param sourceIP
     * @param destinationIP
     * @param protocol
     * @param packetSize
     * @param comment
     * @param dateTime
     * @throws Exception
     */

    public LogEntry(String sequence, String dateTime, String sourceIP, String destinationIP, String protocol, String packetSize, String comment) throws Exception {
        try {
            int seqInt = Integer.parseInt(sequence);
            int packetInt = Integer.parseInt(packetSize);
            if((seqInt < 1 || seqInt > Integer.MAX_VALUE) || dateTime.length() != 19 || sourceIP == null || destinationIP == null ||
                    (packetInt < 1 || packetInt > 1500) || !((protocol.equals("UDP")) || (protocol.equals("TCP")))) {
                throw new InstantiationException("One or more values are invalid");
            }
        }
        catch (InstantiationException ie) {
            throw new Exception("Skipping Entry");
        }
        this.sequence=sequence;
        this.packetSize=packetSize;
        this.dateTime=dateTime;
        this.sourceIP=sourceIP;
        this.destinationIP=destinationIP;
        this.protocol = protocol;
        this.comment=comment;
    }

    /**
     * 7 getters
     * @return the 7 values
     */

    public String getSequence() {
        return sequence;
    }

    public String getDateTime() {
        return dateTime;
    }

    public String getSourceIP() {
        return sourceIP;
    }

    public String getDestinationIP() {
        return destinationIP;
    }

    public String getProtocol() {
        return protocol;
    }

    public String getComment() {
        return comment;
    }

    public String getPacketSize() {
        return packetSize;
    }

    /**
     * a class that will output as a date and time
     * @return date
     * @throws ParseException
     */

    public Date DateTimeAsDate() throws ParseException {
        SimpleDateFormat form = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date date = form.parse(dateTime);
        return date;
    }

    /**
     * format of the string
     * @return the format
     */
    public String toString() {
        return (getSequence() + ", " + getDateTime() + ", " + getSourceIP() + ", " +
                getDestinationIP() + ", " + getProtocol() + ", " + getPacketSize() + ", "+ getComment());
    }
}