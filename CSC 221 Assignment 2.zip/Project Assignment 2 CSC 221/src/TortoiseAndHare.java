import java.security.SecureRandom;

public class TortoiseAndHare {

    /**
     * Declaration of the MAX_ITERATIONS and MAX_MOVES
     */
    public static final int MAX_ITERATIONS = 1000;
    public static final int MAX_MOVES = 100;

    /**
     * Declaration of the positions
     */
    public int hare_position = 1;
    public int tortoise_position = 1;

    /**
     * A random number generator for the movement of the Hare and the Tortoise
     * @return the value of the random number generator
     */

    public static int randomBetween(int min, int max) {
        SecureRandom random = new SecureRandom();
        return random.nextInt(max + min);
    }

    /**
     * the movement of the Hare
     */

    public void stimulateHareMove() {
        // a variable declaration to random generate the hare movement
        int HareMove = randomBetween(0, 9);

        // if and else if statements that fulfill certain movements based on the number
            if (HareMove == 0 || HareMove == 1) {
                hare_position = hare_position + 0; // sleep
            }
            else if (HareMove == 3) {
                hare_position  = hare_position + randomBetween(1, 10) - 11; // Big Slip
            }
            else if (HareMove == 4 || HareMove == 5) {
                hare_position = hare_position + randomBetween(1, 2) - 3; // Small slip
            }
            else if (HareMove == 6 || HareMove == 7) {
                hare_position  = hare_position + randomBetween(1, 9); // Jump
            }
            else {
                hare_position = hare_position  + randomBetween(0, 1); // Walk
            }
            if (hare_position <= 0) {
                hare_position = 1; // to prevent from going backwards
            }
    }

    /**
     * the movement of the Tortoise
     */

    public void stimulateTortoiseMove() {
        // a variable declaration to random generate the tortoise movement
        int TortoiseMove = randomBetween(0, 9);

        // a switch system to declare the tortoise movement
        switch(TortoiseMove) {
            // sleep
            case 0:
                tortoise_position = tortoise_position + 0;
                break;
            // slip
            case 1:
            case 2:
                tortoise_position = tortoise_position + (randomBetween(1, 6) - 7);
                break;
            // walk
            case 3:
            case 4:
                tortoise_position = tortoise_position + (randomBetween(0, 1));
                break;
            // jump
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
                tortoise_position = tortoise_position + (randomBetween(1, 4));
                break;
        }
        if (tortoise_position <= 0) {
            tortoise_position = 1; // to prevent from going backwards
        }
        }

    /**
     * the printing of the positions between the Tortoise and the Hare
     */

    public void PrintPositions() {

        // a for loop of their movement
        for (int i = 1; i < MAX_MOVES; ++i) {
            // if they both are in the same position, then the position is B as in Both
            if ((i == tortoise_position) && (i == hare_position)) {
                System.out.printf("B");
            }
            // tortoise location
            else if((i == tortoise_position) && (i != hare_position)) {
                System.out.printf("T");
            }
            // hare location
            else if((i != tortoise_position) && (i == hare_position)) {
                System.out.printf("H");
            }
            // nothing happens
            else {
                System.out.printf(" ");
            }
        }
        System.out.println("\n");
        for (int i = 1; i<= 100; ++i) {
            System.out.printf("_");
        }
    }


    /**
     * constructor
     */
    TortoiseAndHare() {

        // the start message
        System.out.println("ON YOUR MARK, GET SET");
        System.out.println("BANG!!! ");
        System.out.println("AND THEY'RE OFF!! \n");

        // the declaration of positions
        int tposition = 1;
        int hposition = 1;

        // declaration of the iteratioins
        int iterations;

        // a for loop until the iterations hit MAX_ITERATIONS
        for (iterations = 0; iterations <= MAX_ITERATIONS; ++iterations) {
            System.out.println("Iteration: " + iterations);
            // declaration of the three functions
            PrintPositions();
            stimulateHareMove();
            stimulateTortoiseMove();

            tposition = tortoise_position;
            hposition = hare_position;
            System.out.println("\n");
            // if the tortoise and/or the hare hits 100 before the iterations, this will stop the for loop
            if ((tortoise_position == MAX_MOVES) || (hare_position == MAX_MOVES))
                break;
        }

        // the case where the tortoise wins before MAX_ITERATIONS
        if (tortoise_position == MAX_MOVES) {
            System.out.println("TORTOISE WINS!!! YAY!!!");
            System.out.println("Time Elapsed: " + iterations);
        }

        // the case where the hare wins before MAX_ITERATIONS
        else if (hare_position == MAX_MOVES) {
            System.out.println("Hare wins. Yuch!");
            System.out.println("Time Elapsed: " + iterations);
        }

        // the case when the hare and the tortoise both make it at the same time
        else if (hposition == MAX_MOVES && tposition == MAX_MOVES) {
            System.out.println("It's a tie");
            System.out.println("Time Elasped: " + iterations);
        }

        // the case when no one wins on time
        else {
            System.out.println("Time Out!");
            System.out.println("Time Elapsed: " + (iterations - 1));
        }
    }

    /**
     * the main function
     * @param args
     */
    public static void main(String[] args) {

        //declaration of the constructor
        new TortoiseAndHare();
    }

}