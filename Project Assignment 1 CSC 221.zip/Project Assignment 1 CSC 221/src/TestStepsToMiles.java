import java.util.Scanner;

public class TestStepsToMiles {

    public static void main(String[] args) {

        // applying the default constructor, for the 1st instance
        StepsToMiles default1 = new StepsToMiles();
        default1.setName("Jane Doe");
        default1.setFeet(5.67);
        default1.setInches(9.81);

        // scanner for the 2nd instance
        Scanner input = new Scanner (System.in);

        // allows the user to enter values for name, feet, and inches
        System.out.printf("%n%n %25s", "Enter name: ");
        String name = input.nextLine();

        System.out.printf("Enter height (ft and in): ");
        double feet = input.nextDouble();
        double inches = input.nextDouble();

        //new line
        System.out.printf("\n");

        // closing the scanner of the 2nd instance
        input.close();

        // declaration of the 2nd instance as a non-default constructor
        StepsToMiles input2 = new StepsToMiles(name, feet, inches);

        //output step
        System.out.printf(" Today's Date: " + StepsToMiles.currDate() + "\n\n");

        //first instance output
        System.out.printf(default1.formatAsString(12345));

        //new line
        System.out.printf("\n");

        //second instance output
        System.out.printf(input2.formatAsString(1000));

    }

}
