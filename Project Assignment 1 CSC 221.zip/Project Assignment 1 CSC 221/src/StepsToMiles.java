import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Author: Melson Heo
 * CSC 221 Assignment 1 Fall 2021
 */

public class StepsToMiles {

    /**
     * Declaring a variable for the user's name
     */

    private String name;

    /**
     * Declaring a variable for the user's height in feet
     */

    private double feet;

    /**
     * Declaring a variable for the user's height in inches
     */

    private double inches;

    /**
     * Default Constructor, setting to their default values
     */

    public StepsToMiles() {
        this.name = null;
        this.feet = -1;
        this.inches = -1;
    }

    /**
     * Non-default constructor that sets the 3 parameters
     * @param name
     * @param feet
     * @param inches
     */

    public StepsToMiles(String name, double feet, double inches) {
        this.name = name;
        this.feet = feet;
        this.inches = inches;
    }

    /**
     * name accessor
     * @return the name string
     */

    public String getName() {
        return name;
    }

    /**
     * name mutator
     * @param name
     */

    public void setName (String name) {
        this.name = name;
    }

    /**
     * feet accessor
     * @return the feet value
     */

    public double getFeet() {
        return feet;
    }

    /**
     * feet mutator
     * @param feet
     */

    public void setFeet (double feet) {
        this.feet = feet;
    }

    /**
     * inches accessor
     * @return the inches value
     */

    public double getInches() {
        return inches;
    }

    /**
     * inches mutator
     * @param inches
     */

    public void setInches (double inches) {
        this.inches = inches;
    }

    /**
     * conversion of ft to inches which will return as inches
     * @return the inches value + feet * 12 (total height in inches, not feet)
     */

    public double heightInches() {
        return inches + feet * 12;
    }

    /**
     * conversion of inches to stride
     * @return stride
     */

    public double strideLengthInches() {
        return heightInches() * 0.413;
    }

    /**
     * conversion of stride to miles which will return as miles
     * @param steps
     * @return miles
     */

    public double miles(int steps) {
        return strideLengthInches() * steps / (12 * 5280);
    }

    /**
     * a string declaration of today's date
     * @return the current date
     */

    public static String currDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/uuuu");
        LocalDate localDate = LocalDate.now();
        return dtf.format(localDate);
    }

    /**
     * a class that formats the string and calculates based on how many steps that convert to miles
     * @param steps
     * @return the string format
     */

    public String formatAsString(int steps) {
        return String.format("%13s: %s \n" +
                        "%13s: %.2f\n" +
                        "%13s: %.2f' %.2f\" \n" +
                        "%13s: %d\n" +
                        "%13s: %.2f miles\n",
                        "Name", name,
                        "Stride", strideLengthInches(),
                        "Height", feet, inches,
                        "Steps", steps,
                        "Walk", miles(steps));
    }

}
